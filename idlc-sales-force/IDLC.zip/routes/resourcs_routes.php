<?php 

Route::resource('divisions', 'DivisionController');
Route::resource('districts', 'DistrictController');
Route::resource('thanas', 'ThanaController');
Route::resource('banks', 'BankController');
Route::resource('branchs', 'BranchController');
Route::resource('nationalitys', 'NationalityController');
Route::resource('premiseOwnerships', 'PremiseOwnershipController');
Route::resource('userTypes', 'UserTypeController');

Route::get('thanas/getThanaByDivisionAndDistrictId','ThanaController@getThanas');
Route::any('get/division','ThanaController@showDivision');
Route::any('branchs/getBranch','BranchController@getBranch');


/** IFA route all**/

Route::group(['middleware' => 'auth'], function () {
	Route::group(['middleware' => 'routeAccess'], function () {

		Route::get('new/application', [
				'as' => 'new_application_view',
				'uses' => 'ifa\NewApplication@create'
			]);

		Route::get('partially/completed/application', [
				'as' => 'partially_completed_application_view',
				'uses' => 'ifa\PartiallyCompleted@viewPartiallyCompleted'
			]);

		Route::get('application/in/progress', [
				'as' => 'application_in_progress_view',
				'uses' => 'ifa\ApplicationProgress@viewApplicationProgress'
			]);

		Route::get('rejected/applications', [
				'as' => 'rejected_applications_view',
				'uses' => 'ifa\RejectedApplication@viewRejectedApplication'
			]);
		Route::get('bulk/upload', [
				'as' => 'bulk_upload_view',
				'uses' => 'ifa\BulkUploadController@AddBulk'
			]);

	});
});


/** HEAD route all**/
Route::group(['middleware' => 'auth'], function () {
	Route::group(['middleware' => 'routeAccess'], function () {

		Route::get('unassigned', [
				'as' => 'unassigned_view',
				'uses' => 'lead\UnassignedController@viewUnassigned'
			]);

		Route::get('converted', [
				'as' => 'converted_view',
				'uses' => 'lead\ConvertedController@viewConverted'
			]);

		Route::get('highly/interested', [
				'as' => 'highly_interested_view',
				'uses' => 'lead\HighlyInterestedController@viewHighlyInterested'
			]);

		Route::get('might/invest', [
				'as' => 'might_invest_view',
				'uses' => 'lead\MightInvestController@viewMightInvest'
			]);

		Route::get('interested', [
				'as' => 'Interested_view',
				'uses' => 'lead\InterestedController@viewInterested'
			]);

		Route::get('pitched', [
				'as' => 'pitched_view',
				'uses' => 'lead\PitchedController@viewPitched'
			]);

		Route::get('conversion/ratio', [
				'as' => 'conversion_ratio_view',
				'uses' => 'lead\ConversionRatioController@viewConversionRatio'
			]);
	});
});