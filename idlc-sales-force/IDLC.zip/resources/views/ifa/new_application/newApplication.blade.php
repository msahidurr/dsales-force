@extends('layouts.dashboard')
@section('page_heading','New Application')
@section('section')
@endsection