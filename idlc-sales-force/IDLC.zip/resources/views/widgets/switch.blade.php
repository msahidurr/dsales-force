<div class="onoffswitch">
  <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="myonoffswitch" checked>
  <label class="onoffswitch-label" for="myonoffswitch">
    <span class="onoffswitch-inner"></span>
    <span class="onoffswitch-switch"></span>
  </label>
</div>
<!-- 
<div class="onoffswitch2">
  <input type="checkbox" name="onoffswitch2" class="onoffswitch-checkbox2" id="myonoffswitch2" checked>
  <label class="onoffswitch-label2" for="myonoffswitch2">
    <span class="onoffswitch-inner2"></span>
    <span class="onoffswitch-switch2"></span>
  </label>

</div>
 -->