<?php

return [
    'login_rememberme_label' => 'Remember Me',
    'dashboard_label' => 'Dashboard',
];
?>