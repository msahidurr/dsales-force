<?php

return [
    'login_rememberme_label' => 'আমাকে মনে কর',
    'dashboard_label' => 'ড্যাশবোর্ড',
];