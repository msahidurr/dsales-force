<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Thana extends Model
{
    protected $table = "tbl_bangladesh_thanas";
    protected $primaryKey = "thana_id";
}
