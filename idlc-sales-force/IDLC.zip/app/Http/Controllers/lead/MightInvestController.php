<?php

namespace App\Http\Controllers\lead;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MightInvestController extends Controller
{
    public function viewMightInvest(){
    	return view('lead.might_invest.mightInvestList');
    }
}
