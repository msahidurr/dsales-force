<?php

namespace App\Http\Controllers\lead;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ConvertedController extends Controller
{
    public function viewConverted(){
    	return view('lead.converted.convertedList');
    }
}
