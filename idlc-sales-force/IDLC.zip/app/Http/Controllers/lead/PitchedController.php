<?php

namespace App\Http\Controllers\lead;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PitchedController extends Controller
{
    public function viewPitched(){
    	return view('lead.pitched.pitchedList');
    }
}
