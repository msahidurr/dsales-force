<?php

namespace App\Http\Controllers\lead;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HighlyInterestedController extends Controller
{
    public function viewHighlyInterested(){
    	return view('lead.highly_interested.higlyInterestedList');
    }
}
