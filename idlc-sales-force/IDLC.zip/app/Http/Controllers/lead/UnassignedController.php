<?php

namespace App\Http\Controllers\lead;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UnassignedController extends Controller
{
    public function viewUnassigned(){
    	return view('lead.unassigned.unassignedList');
    }
}
