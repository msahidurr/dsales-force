<?php

namespace App\Http\Controllers\lead;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class InterestedController extends Controller
{
     public function viewInterested(){
    	return view('lead.interested.interestedList');
    }
}
