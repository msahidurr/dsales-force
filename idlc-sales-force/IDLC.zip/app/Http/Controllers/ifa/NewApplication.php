<?php

namespace App\Http\Controllers\ifa;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class NewApplication extends Controller
{
    public function viewNewApplication(){
    	return view('ifa.new_application.newApplication');
    }

    public function create($application_no = 0, $step = 1) {

        $data = [
            'application_no' => $application_no,
            'step' => $step,
        ];
        return view('ifa_registration_form.create', $data);
    }
}
