<?php

namespace App\Http\Controllers\ifa;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ApplicationProgress extends Controller
{
    public function viewApplicationProgress(){
    	return view('ifa.application_in_progress.applicationProgressList');
    }
}
