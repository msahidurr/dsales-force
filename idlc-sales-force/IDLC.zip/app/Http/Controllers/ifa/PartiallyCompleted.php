<?php

namespace App\Http\Controllers\ifa;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PartiallyCompleted extends Controller
{
    public function viewPartiallyCompleted(){
    	return view('ifa.partialty_completed.partialtyCompleteList');
    }
}
