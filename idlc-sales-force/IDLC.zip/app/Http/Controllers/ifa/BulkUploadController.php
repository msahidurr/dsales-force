<?php

namespace App\Http\Controllers\ifa;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BulkUploadController extends Controller
{
    public function AddBulk(){
    	return view('ifa.bulk_upload.addBulk');
    }
}
