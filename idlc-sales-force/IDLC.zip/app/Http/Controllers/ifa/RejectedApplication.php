<?php

namespace App\Http\Controllers\ifa;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class RejectedApplication extends Controller
{
    public function viewRejectedApplication(){
    	return view('ifa.rejected_application.rejectedApplicationList');
    }
}
