<?php $__env->startSection('page_heading','Bulk Upload'); ?>
<?php $__env->startSection('section'); ?>
<div class="col-sm-8 col-sm-offset-2">
	<div class="panel panel-default">
		<div class="panel-body">
			<form action="#" method="POST" role="form" >
				<?php echo e(csrf_field()); ?>


				<div class="form-group">
					<label class="col-sm-4 control-label" for="bulkupload"> <span class="pull-right">Upload IFA Member List</span></label>
					<div class="col-sm-6">
						<input type="file" name="bulk" class="form-control-file" id="bulkupload">
					</div>
				</div>

				<div class="form-group">
                    <div class="col-sm-6 col-sm-offset-6 col-xs-offset-8">
                        <button type="submit" class="btn btn-primary" style="margin-right: 15px;">Upload
                        </button>
                    </div>
            	</div>
				
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>