<?php $__env->startSection('page_heading','New Application'); ?>
<?php $__env->startSection('section'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>