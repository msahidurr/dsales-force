<?php $__env->startSection('section'); ?>
<div class="panel panel-default col-sm-10 col-sm-offset-1 main_body">
	<div class="header">
		<div class="panel panel-default ">
			<div class="panel-heading">
				<center><h2>User Type List Page</h2></center>
			</div>
		</div>
	</div>

	<div class="panel-body">
		<div class="col-sm-12 col-xs-12 menu">
			<div class="col-sm-2 col-xs-12">
				<div class="form-group ">
					<a href="<?php echo e(route('userTypes.create')); ?>" class="btn btn-primary ">Add User Type
					<i class="fa fa-plus"></i></a>
				</div>
			</div>

			    <div class="col-sm-8 form-group">
			        <input type="text" name="searchFld" class="form-control" placeholder="search">			        
			    </div>

			    <div class="col-sm-2">
			    	<button class="btn btn-default" type="button">
			            <i class="fa fa-search"></i>
			        </button>
			    </div>
		</div>

		<div class="col-sm-12">
			<table class="table table-bordered table-striped">
				
				<thead>
				<th width="5%">Serial</th>
				<th width="15%">Nationality</th>
				<th width="15%">Status</th>
				<th width="10%">Action</th>	
				</thead>


				<tbody>
					<?php ($i =1 ); ?>
					<?php $__currentLoopData = $UserTypeDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UserTypeValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($i++); ?></td>
							<td><?php echo e($UserTypeValue->user_type); ?></td>
							<td>
								<?php echo e(($UserTypeValue->is_active == 1)? "Active":"Inactive"); ?>

							</td>
							<td>
								<table>
									<tbody>
										<tr>
											<td >
												<a href="<?php echo e(route('userTypes.edit',[$UserTypeValue->id_user_type])); ?>" class="btn btn-success">Edit</a>
											</td>
											<td>
												<form action="<?php echo e(route('userTypes.destroy',[$UserTypeValue->id_user_type])); ?>" method="POST">
													<?php echo csrf_field(); ?>

													<?php echo method_field('DELETE'); ?>

													<input type="submit" value="Delete" class="btn btn-danger deleteButton">
												</form>
											</td>
										</tr>
									</tbody>
								</table>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			<?php echo e($UserTypeDetails->links()); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.idlc_aml.division_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>